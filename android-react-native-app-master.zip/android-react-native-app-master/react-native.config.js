module.exports = {
    project: {
        android: {
            sourceDir: './'
        }
    }
};
