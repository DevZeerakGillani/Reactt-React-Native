package com.example.androidreactnativeapp;

import androidx.annotation.Nullable;

import com.facebook.react.ReactActivity;

public class RNPropertyDetails extends ReactActivity {

    @Nullable
    @Override
    protected String getMainComponentName() {
        return "RNPropertyDetails";
    }
}
